
`rm -R ./ams2d_
`
